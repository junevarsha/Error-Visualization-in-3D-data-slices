/**CS880 Scientific data visualization
 * Project final submission
 * Submitted by 
 * Varsha Thirumakil
 */
/**
 * SceneManager: Manages all the scenes and initiates drawing of current scene.
 *               Implements the Singleton class pattern, but also uses a static
 *               interface to interact with ControlPanel and the Scene class
 * 
 * @author rdb
 * @date 10/17/13
 * 
 */
import java.io.IOException;
import java.io.InputStream;
import java.util.*;
import java.awt.*;
import java.awt.image.BufferedImage;

import javax.media.opengl.*;
import javax.media.opengl.awt.GLCanvas;
import javax.media.opengl.glu.*;
import javax.swing.JFrame;

import com.jogamp.opengl.util.FPSAnimator;
import com.jogamp.opengl.util.gl2.GLUT;
import com.jogamp.opengl.util.texture.Texture;
import com.jogamp.opengl.util.texture.TextureIO;
import com.jogamp.opengl.util.texture.awt.AWTTextureIO;

public class SliceQuad implements GLEventListener {
	// ------------------- class variables ---------------------------
	public static SliceQuad me = null;
	private static boolean drawAxesFlag = true;
	private static boolean lightingFlag = true;
	private static LinkedList<Scene> allScenes;
	private static int curSceneIndex = -1;
	private static Scene curScene = null;
	private static float[] diffuseLight;

	private static GLCanvas canvas;
	private FPSAnimator animator;

	// Texture params
	private Texture[] dataTex = new Texture[3];
	private Texture[] errorTex = new Texture[3];
	private Texture[] errorTex1 = new Texture[3];
	private static ControlPanel cp = null;

	private int preSX = 0;
	private int preEX = 0;

	private int preSY = 0;
	private int preEY = 0;

	private int preSZ = 0;
	private int preEZ = 0;



	Model modObj;

	ViewSlice viewsObj = null;
	BufferedImage bufView = null;

	ViewSlice viewsObj2 = null;
	BufferedImage bufView2 = null;

	ViewSlice viewsObj3 = null;
	BufferedImage bufView3 = null;

	boolean needTextureX = true;
	boolean needTextureY = true;
	boolean needTextureZ = true;

	// ------------------- instance variables ------------------------

	// For testing, we'll keep pointers to a bunch of created objects in a
	// vector
	// also. This makes it easy to just select previously created objects
	// for multiple scenes, or to copy them and change transformations.
	private ArrayList<Object3D> someObjects;

	// ------------------ constructor --------------------------------
	public static SliceQuad getInstance() {
		if (me == null)
			me = new SliceQuad();
		return me;
	}

	private SliceQuad() {

		setCanvas(ThreeD.glCanvas);
		allScenes = new LinkedList<Scene>();
		someObjects = new ArrayList<Object3D>();
		// lightColor = new Color( 0.7f, 0.7f, 0.7f );
		diffuseLight = new float[] { 0.0f, 0.7f, 0.7f, 1f };

		animator = new FPSAnimator(ThreeD.glCanvas, 56);
		animator.start();
	}

	// ----------------- setCanvas -------------------------------------
	/**
	 * Main program needs to tell sceneManager about the GL canvas to use
	 */
	public void setCanvas(GLCanvas glCanvas) {
		canvas = glCanvas;
	}

	// ------------------------- addScene -------------------------------
	/**
	 * Add a new scene to the scene collection
	 */
	public static void addScene(Scene newScene) {
		allScenes.add(newScene);
		curScene = newScene;
		curSceneIndex = allScenes.size() - 1;
	}

	// ------------------------- nextScene -------------------------------
	/**
	 * update current scene to next one with wraparound this is a static method
	 * to facilitate interaction with ControlPanel
	 */
	public static void nextScene() {
		curSceneIndex++;
		if (curSceneIndex >= allScenes.size()) {
			curSceneIndex = 0;
		}// wrap around
		canvas.repaint();
	}

	public static void previousScene() {

		// wrap around

		if (curSceneIndex == 0) {
			curSceneIndex = allScenes.size() - 1;
		} else {

			curSceneIndex--;
		}
		canvas.repaint();

	}

	// ------------------------- setDrawAxes( boolean ) ------------------
	/**
	 * set the status of the axes drawing; called by ControlPanel
	 */
	public static void setDrawAxes(boolean onoff) {
		drawAxesFlag = onoff;
		canvas.repaint();
	}

	// ------------------------- drawAxes() ------------------
	/**
	 * retrieve axes drawing status; called by Scene
	 */
	public static boolean drawAxes() {
		return drawAxesFlag;
	}

	// ------------------------- setL( boolean ) ------------------
	/**
	 * set the status of the axes drawing; called by ControlPanel
	 */
	public static void setLighting(boolean onoff) {
		lightingFlag = onoff;
		canvas.repaint();
	}

	// ------------------------- drawAxes() ------------------
	/**
	 * retrieve axes drawing status; called by Scene
	 */
	public static boolean lighting() {
		return lightingFlag;
	}

	// ------------ setLightColor ----------------------
	public static void setLightColor(Color c) {
		diffuseLight[0] = c.getRed() / 255.0f;
		diffuseLight[1] = c.getGreen() / 255.0f;
		diffuseLight[2] = c.getBlue() / 255.0f;
		diffuseLight[3] = c.getAlpha() / 255.0f;
		System.out.println("New Color: " + c);
		sceneInit();
		canvas.repaint();
	}

	// +++++++++++++++ GLEventListener override methods ++++++++++++++++++++
	// -------------------- display -------------------------------------
	/**
	 * Override the parent display method In this framework, the display method
	 * is responsible for setting up the projection specification, but the
	 * "render" method is responsible for the View and Model specifications.
	 * 
	 * This display method is reasonably application-independent; It defines a
	 * pattern that can be reused with the exception of the specifying the
	 * actual objects to render.
	 */
	@Override
	public void display(GLAutoDrawable drawable) {

		// System.out.println("calling disp");

		makeTexture();

		curScene.display(drawable);

		canvas.repaint();
	}

	private void makeTexture() {

		curScene = allScenes.get(curSceneIndex);
		if (curScene != null) {
			sceneInit();
			
			 if(preSX != ControlPanel.sx){
				 needTextureX = true ; 
				 preSX = ControlPanel.sx ; 
			 }
			 
			 //***** Error : *****
			 
//			 if(preSX != ControlPanel.sx){
//				 needTextureX = true ; 
//				 preSX = ControlPanel.sx ; 
//			 }
			 
			 if((preSX != ControlPanel.sx) || (preEX != ControlPanel.error1SliceIndex)) 
			 
			 {
				 needTextureX = true ; 
				 preSX = ControlPanel.sx ; 
				 preEX = ControlPanel.error1SliceIndex;
			 }
			 
			 
			
			if (needTextureX == true) {

				generateTextureObjects(ControlPanel.sx,
						ControlPanel.error1SliceIndex,
						ControlPanel.error2SliceIndex, 0);
				needTextureX = false;

			}
			
			 if(preSY != ControlPanel.sy){
				 needTextureY = true ; 
				 preSY = ControlPanel.sy ; 
			 }
			
			
			if (needTextureY == true) {
				generateTextureObjects(ControlPanel.sy,
						ControlPanel.error1SliceIndex,
						ControlPanel.error2SliceIndex, 1);
				needTextureY = false;

			}
			
			 if(preSZ != ControlPanel.sz){
				 needTextureZ = true ; 
				 preSZ = ControlPanel.sz ; 
			 }
			 
			if (needTextureZ == true) {
				generateTextureObjects(ControlPanel.sz,
						ControlPanel.error1SliceIndex,
						ControlPanel.error2SliceIndex, 2);

				needTextureZ = false;
			}

			modifySceneObjects();
		}
	}

	// --------------------- dispose ------------------------------
	@Override
	public void dispose(GLAutoDrawable arg0) {
		// nothing to dispose of...
	}

	// --------------------- init ------------------------------
	@Override
	public void init(GLAutoDrawable drawable) {
		JOGL.gl = drawable.getGL().getGL2();

		JOGL.gl.setSwapInterval(1); // animation event occurs (maybe)
									// only at end of frame draw.
									// 0 => render as fast as possible
		JOGL.glu = new GLU();
		JOGL.glut = new GLUT();

		sceneInit();

		makeSimpleScenes(); // make scenes with at least 1 example of each
							// Object3D
		// makeMultiObjectScenes();
		nextScene();
	}

	// --------------------- reshape ----------------------------------------
	/**
	 * Window has been resized, readjust internal information
	 */
	@Override
	public void reshape(GLAutoDrawable drawable, int x, int y, int w, int h) {
		System.out.println("reshape");
		JOGL.gl = drawable.getGL().getGL2();
		JOGL.gl.glViewport(0, 0, w, h);
		System.out.println("Viewport size: " + w + " x " + h);
	}

	// ----------------- makeBox ----------------------------
	/**
	 * A convenience function to create a Sphere with a uniform scale, a
	 * specified color, and at 0,0,0.
	 */
	Quad makeBox(float scale, Color c) {
		Quad box = new Quad();
		box.setColor(c);
		// box.setLocation(0, 0, 0);
		// box.setSize(1.2f, 1.3f, 1.4f);
		return box;
	}

	// --------------------- sceneInit ------------------------
	/**
	 * Initialize scene, including especially the lights
	 */
	public static void sceneInit() {
		JOGL.gl.glClearColor(1.0f, 1.0f, 1.0f, 0.0f);// black
		JOGL.gl.glClearDepth(1.0); // clears depth buffer
		JOGL.gl.glEnable(GL2.GL_DEPTH_TEST); // Enable depth testing
		JOGL.gl.glShadeModel(GL2.GL_SMOOTH); // Enable smooth color shading
		JOGL.gl.glEnable(GL2.GL_NORMALIZE); // Make all surface normals unit len
		JOGL.gl.glEnable(GL2.GL_COLOR_MATERIAL); // Current color used for

		float ambientLight[] = { 0.3f, 0.3f, 0.3f, 1f };
		JOGL.gl.glLightfv(GL2.GL_LIGHT0, GL2.GL_AMBIENT, ambientLight, 0);

		/****
		 * float diffuseLight[] = { lightColor.getRed(), lightColor.getGreen(),
		 * lightColor.getBlue(), 1f }; /
		 **/
		JOGL.gl.glLightfv(GL2.GL_LIGHT0, GL2.GL_DIFFUSE, diffuseLight, 0);

		// Set the light position
		// GLfloat lightPosition[] = {-1, 1, 1, 0};
		float lightPosition[] = { -1, 1, 1, 0 };
		JOGL.gl.glLightfv(GL2.GL_LIGHT0, GL2.GL_POSITION, lightPosition, 0);

	}

	// ------------------------- changeEvent -----------------------------
	static void changeEvent(String id, int value) {
		curScene.changeEvent(id, value);
		canvas.repaint();
	}

	// ------------------------- makeSimpleScenes --------------------------
	/**
	 * make all one object scenes
	 */
	void makeSimpleScenes() {

		// First Slice object

		Quad box1 = makeBox(1, new Color(1f, 0f, 1f)); // unit magenta box
		// box1.setSize(0.7f, 0.7f, 0.7f);
		//box1.setSize(2.5f, 2.3f, 2.5f);
		box1.setSize(2.2f, 2.4f, 2.2f);

		 box1.setLocation(0.5f, 0.2f, 0.2f);

		//box1.setLocation(0.8f, 0.3f, 0.2f);

		box1.setRotate(90.0f, 1.0f, 0.0f, 0.0f);
		box1.setColor(Color.CYAN);
		box1.setDataTex(dataTex[0]);
		box1.setErrorTex(errorTex[0]);
		box1.setErrorTex1(errorTex1[0]);
		someObjects.add(box1); // save it for future use

		Quad box2 = makeBox(1, new Color(1f, 0f, 1f)); // unit magenta box
		// box2.setSize(0.7f, 0.7f, 0.7f);
		//box2.setSize(2.5f, 2.3f, 2.5f);
		

		box2.setSize(2.7f, 2.3f, 3.7f);

		box2.setLocation(0.1f, 0.0f, 0.1f);

		// box2.setLocation(0.5f, 0.2f, 0.1f);

		box2.setRotate(360.0f, 0.0f, 1.0f, 1.0f);
		box2.setColor(Color.magenta);
		box2.setDataTex(dataTex[1]);
		box2.setErrorTex(errorTex[1]);
		box2.setErrorTex1(errorTex1[1]);
		someObjects.add(box2); // save it for future use

		Quad box3 = makeBox(1, new Color(0f, 0f, 1f)); // unit magenta box
		// box3.setSize(0.7f, 0.7f, 0.7f);
		box3.setSize(2.5f, 2.3f, 2.5f);


		box3.setLocation(0.2f, 0.1f, 0.2f);
		// box3.setLocation(0.2f, 0.1f, 0.2f);

		box3.setColor(Color.red);
		box3.setRotate(180.0f, 1.0f, 0.0f, 1.0f);
		box3.setDataTex(dataTex[2]);
		box3.setErrorTex(errorTex[2]);
		box3.setErrorTex1(errorTex1[2]);
		someObjects.add(box3); // save it for future use

		modObj = new Model(box1, box2, box3);

		Scene box1Scene = new Scene();
		// box1Scene.addObject(box1);
		// box1Scene.addObject(box2);
		// box1Scene.addObject(box3);
		// someObjects.add(modObj);
		box1Scene.addObject(modObj);
		addScene(box1Scene);

	}

	void modifySceneObjects() {

		// Model modObj = (Model) someObjects.get(0) ;
		cp = ControlPanel.getInstance();

		// if(ControlPanel.rotate.isSelected()){
		// modObj.setRotateModel(true);
		// modObj.setModelRotateAngle(ControlPanel.angRot);
		// }

		// Quad box1 = modObj.getObj1() ;
		Quad box1 = (Quad) someObjects.get(0);
		box1.setDataTex(dataTex[0]);
		box1.setErrorTex(errorTex[0]);
		box1.setErrorTex1(errorTex1[0]);

		// Quad box2 = modObj.getObj2() ;
		Quad box2 = (Quad) someObjects.get(1);
		box2.setDataTex(dataTex[1]);
		box2.setErrorTex(errorTex[1]);
		box2.setErrorTex1(errorTex1[1]);

		// Quad box3 = modObj.getObj3() ;
		Quad box3 = (Quad) someObjects.get(2);
		box3.setDataTex(dataTex[2]);
		box3.setErrorTex(errorTex[2]);
		box3.setErrorTex1(errorTex1[2]);

	}

	void setLight() {
		if (ControlPanel.point.isSelected()) {
			JOGL.gl.glEnable(GL2.GL_LIGHTING);
			JOGL.gl.glEnable(GL2.GL_LIGHT0);
			float ambientLight[] = { 0.3f, 0.3f, 0.3f, 1f };
			JOGL.gl.glLightfv(GL2.GL_LIGHT0, GL2.GL_AMBIENT, ambientLight, 0);
			float lightPosition[] = { -1, 2, 1, 0 };
			JOGL.gl.glLightfv(GL2.GL_LIGHT0, GL2.GL_POSITION, lightPosition, 0);

			JOGL.gl.glLightfv(GL2.GL_LIGHT0, GL2.GL_DIFFUSE, diffuseLight, 0);
			// System.out.println("DLight: <" + diffuseLight[0] + ", "
			// + diffuseLight[1] + ", " + diffuseLight[2] + ">");

		}

	}

	// ------------------------- makeMultiObjectScenes-------------------- //
	/**
	 * make all one object scenes
	 * 
	 */

	void makeMultiObjectScenes() {
		Scene multi1 = new Scene();
		Object3D box = makeBox(1, new Color(1f, 0f, 1f)); // magenta
		box.setLocation(1f, 0f, 0f);
		box.setSize(0.4f, 0.4f, 0.4f);
		multi1.addObject(box);

		Object3D box2 = makeBox(0.5f, new Color(0f, 1f, 1f)); // cyan
		box2.setLocation(0f, 0f, 1f);
		multi1.addObject(box2);

		addScene(multi1);

	}

	private void openDataSource(int sx, int error1SliceIndex,
			int error2SliceIndex, int sAxis) {

		System.out.println("Inside openDataSource method");
		JFrame frame = new JFrame("ViewSlice");

		String[] argsWalnutOrg = new String[12];

		argsWalnutOrg[0] = "-" + sx;
		argsWalnutOrg[1] = "-x";
		argsWalnutOrg[2] = "2";
		argsWalnutOrg[3] = "-a";
		argsWalnutOrg[4] = "0";
		argsWalnutOrg[5] = "-l";
		argsWalnutOrg[6] = "gray";
		argsWalnutOrg[7] = "-min";
		argsWalnutOrg[8] = "";
		argsWalnutOrg[9] = "-max";
		argsWalnutOrg[10] = "";
		argsWalnutOrg[11] = "walnut/walnut.xfdl";

		String[] argsHeadSNR = new String[12];
		argsHeadSNR[0] = "-" + error1SliceIndex;
		argsHeadSNR[1] = "-x";
		argsHeadSNR[2] = "2";
		argsHeadSNR[3] = "-a";
		argsHeadSNR[4] = "0";
		argsHeadSNR[5] = "-l";
		argsHeadSNR[6] = "gray";
		argsHeadSNR[7] = "-min";
		argsHeadSNR[8] = "";
		argsHeadSNR[9] = "-max";
		argsHeadSNR[10] = "";
		argsHeadSNR[11] = "headf/headf.bin.snr.d1.e4.fdl";
		// argsHead[11] = "headf/headf.bin.stddev.d1.e4.fdl";

		String[] argsWalnutSNR = new String[12];
		argsWalnutSNR[0] = "-" + error2SliceIndex;
		argsWalnutSNR[1] = "-x";
		argsWalnutSNR[2] = "2";
		argsWalnutSNR[3] = "-a";
		argsWalnutSNR[4] = "0";
		argsWalnutSNR[5] = "-l";
		argsWalnutSNR[6] = "gray";
		argsWalnutSNR[7] = "-min";
		argsWalnutSNR[8] = "";
		argsWalnutSNR[9] = "-max";
		argsWalnutSNR[10] = "";
		argsWalnutSNR[11] = "walnut/walnut.bin.snr.d1.e4.fdl";

		System.out.println("inside datsource");

		viewsObj = new ViewSlice(frame, argsWalnutOrg);

		viewsObj2 = new ViewSlice(frame, argsHeadSNR);

		viewsObj3 = new ViewSlice(frame, argsWalnutSNR);

	}

	private void generateTextureObjects(int sx, int error1SliceIndex,
			int error2SliceIndex, int sAxis) {

		System.out.println("Inside generateTextureObject method");

		openDataSource(sx, error1SliceIndex, error2SliceIndex, sAxis);

		bufView = viewsObj.updateSlice2(0);// return bufimg
		// 0, half of z
		InputStream stream1 = getClass().getResourceAsStream("bufView");

		dataTex[sAxis] = AWTTextureIO.newTexture(GLProfile.getDefault(),
				bufView, true);

		bufView2 = viewsObj2.updateSlice2(1);// return bufimg
		//

		InputStream stream2 = getClass().getResourceAsStream("bufView2");

		errorTex[sAxis] = AWTTextureIO.newTexture(GLProfile.getDefault(),
				bufView2, true);

		System.out.println("inside vo3");
		bufView3 = viewsObj3.updateSlice2(2);// return bufimg
		//

		InputStream stream3 = getClass().getResourceAsStream("bufView3");
		errorTex1[sAxis] = AWTTextureIO.newTexture(GLProfile.getDefault(),
				bufView3, true);

	}
}