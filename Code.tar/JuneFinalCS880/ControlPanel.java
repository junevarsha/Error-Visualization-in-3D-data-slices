/**
/**CS880 Scientific data visualization
 * Project final submission
 * Submitted by 
 * Varsha Thirumakil
 */
/**
 * ControlPanel -- GUI Control panel with GLCanvas inside it
 * 
 */

import javax.media.opengl.GL;
import javax.media.opengl.GL2;
import javax.media.opengl.GLBase;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.border.*;

import java.awt.*;
import java.awt.event.*;

public class ControlPanel extends JPanel {
	// ---------------- class variables ------------------------------
	private static ControlPanel instance = null;
	public static JButton prevButton;
	public static JButton dataButton;
	public static JButton errorButton;
	public static JRadioButton radioButton;
	public static JRadioButton radioButton1;
	public static JRadioButton radioButton2;

	public static JCheckBox scale;
	public static JCheckBox rotate;

	public static int sx = 250;
	public static int sy = 80;
	public static int sz = 350;

	public static JCheckBox point;
	public static JCheckBox directional;
	public static boolean light_on = false;

	// private static JSlider sliceIndex;
	private static JSlider sliceX;
	private static JSlider sliceY;
	private static JSlider sliceZ;

	private static JSlider sxSlider;
	private static JSlider sySlider;
	private static JSlider szSlider;

	private static JSlider rxSlider;
	private static JSlider rySlider;
	private static JSlider rzSlider;
	public static JSlider angle;

	private static JSlider rotY;
	private static JSlider rotZ;

	public static JSlider scaleX;
	public static JSlider scaleY;
	public static JSlider scaleZ;

	private static JSpinner dataSliceSpinner;
	private static JSpinner error1SliceSpinner;
	private static JSpinner error2SliceSpinner;
	private static JSpinner transformSliceSpinner;

	public static JRadioButton ambient;
	public static JRadioButton diffuse;
	public static JRadioButton specular;

	public static JCheckBox light;
	public static JCheckBox dataSource;
	public static JCheckBox errorSource;
	public static JCheckBox errorSource1;
	public static JCheckBox errorSource2;
	public static int dataSliceIndex = 200;
	// public static int dataSliceIndex = 500;

	public static int error1SliceIndex = 10;
	public static int error2SliceIndex = 40;
	public static int transformSliceIndex = 1;

	private static JPanel bPanel = new JPanel();
	private static JFrame cp = new JFrame(" Interactive GUI");

	public static boolean changeTransformation = false;

	float tx, ty, tz, zx, zy, zz, rx, ry, rz ;
	
	public static float angRot ; 

	// --------------- instance variables ----------------------------
	JPanel drawPanel = null; // this will be used for the rendering area

	// ------------------- constructor -------------------------------
	/**
	 * return singleton instance of ControlPanel
	 */
	public static ControlPanel getInstance() {
		if (instance == null)
			instance = new ControlPanel();
		return instance;
	}

	/**
	 * Constructor is private so can implement the Singleton pattern
	 */
	ControlPanel() {
		this.setLayout(new BorderLayout());
		buildGUI();
	}

	// --------------- addDrawPanel() -----------------------------
	/**
	 * add component to draw panel
	 */
	public void addDrawPanel(Component drawArea) {
		this.add(drawArea, BorderLayout.CENTER);
	}

	// --------------- getDrawPanel() -----------------------------
	/**
	 * return reference to the drawing area
	 */
	public JPanel getDrawPanel() {
		return drawPanel;
	}

	// --------------- nextScene() -------------------------------
	/**
	 * Go to the next scene
	 */
	public void nextScene() {
		System.out.println("Next Scene");
	}

	// --------------- build GUI components --------------------
	/**
	 * Create all the components
	 */
	private void buildGUI() {

		tx = 0.0f;
		ty = 0.0f;
		tz = 0.0f;

		zx = 0.0f;
		zy = 0.0f;
		zz = 0.0f;

		rx = 1.0f;
		ry = 0.0f;
		rz = 0.0f;

		// build the button menu
		buildButtons();

		// build sliders
		buildJPanel(cp.getContentPane());

		// appInit();

		// buildRadio();
	}

	// --------------------- buildButtons ------------------------------------
	/**
	 * build a button panel: a Next button and an DrawAxis CheckBox
	 */
	private void buildButtons() {
		JPanel bPanel = new JPanel();
		bPanel.setBorder(new LineBorder(Color.BLACK, 2));

		JButton nextButton = new JButton("Next Scene");
		nextButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				SliceQuad.nextScene();
			}
		});
		// bPanel.add(nextButton);

		point = new JCheckBox("PointSource");

		// bPanel.add(point);
		directional = new JCheckBox("Directional");
		// bPanel.add(directional);

		light = new JCheckBox("Lighting");
		light.setSelected(true);
		light.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				SliceQuad.setLighting(((JCheckBox) ae.getSource()).isSelected());
			}
		});

		// bPanel.add(light);
		this.add(bPanel, BorderLayout.NORTH);

	}

	// ------------------- buildSliders ---------------------------------
	/**
	 * Create 3 sliders and add using border layout: First argument is the
	 * containing JFrame into which the sliders will be placed 2nd argument is a
	 * reference to the JShape that is being controlled.
	 * 
	 * West region will have a vertical slider controlling the y position South
	 * region will have the slider controlling the x position East region will
	 * have a slider controlling the size
	 */
	// private void buildSliders() {

	private void appInit() {

		// JOGL.gl.glClear(GL.GL_COLOR_BUFFER_BIT | GL.GL_DEPTH_BUFFER_BIT);

		JOGL.gl.glClearDepth(5.0); // sets farthest z-value
		JOGL.gl.glEnable(GL2.GL_DEPTH_TEST); // Enable depth testing
		JOGL.gl.glShadeModel(GL2.GL_SMOOTH); // Enable smooth shading
		JOGL.gl.glEnable(GL2.GL_NORMALIZE); // Make all normals unit len
		JOGL.gl.glEnable(GL2.GL_COLOR_MATERIAL);

		// Set material properties.
		float[] matAmbient = { 0.7f, 0.7f, 0.7f, 1.0f };
		float[] matDiffuse = { 0.8f, 0.8f, 0.8f, 1.0f };
		float[] matSpecular = { 1.0f, 1.0f, 1.0f, 1.0f };
		float[] highShininess = { 50.0f };

		JOGL.gl.glMaterialfv(GL2.GL_FRONT, GL2.GL_AMBIENT, matAmbient, 0);
		JOGL.gl.glMaterialfv(GL2.GL_FRONT, GL2.GL_DIFFUSE, matDiffuse, 0);
		JOGL.gl.glMaterialfv(GL2.GL_FRONT, GL2.GL_SPECULAR, matSpecular, 0);
		JOGL.gl.glMaterialfv(GL2.GL_FRONT, GL2.GL_SHININESS, highShininess, 0);

		// Prepare light parameters.
		float lightAmbient[] = { 0.2f, 0.2f, 0.2f, 1.0f };
		float lightDiffuse[] = { 0.6f, 0.6f, 0.6f, 1.0f };
		float lightSpecular[] = { 1.0f, 1.0f, 1.0f, 1.0f };
		float lightPosition[] = { 30.0f, 30.0f, 0.0f };

		// Set light parameters.
		JOGL.gl.glLightfv(GL2.GL_LIGHT0, GL2.GL_AMBIENT, lightAmbient, 0);
		JOGL.gl.glLightfv(GL2.GL_LIGHT0, GL2.GL_DIFFUSE, lightDiffuse, 0);
		JOGL.gl.glLightfv(GL2.GL_LIGHT0, GL2.GL_SPECULAR, lightSpecular, 0);
		JOGL.gl.glLightfv(GL2.GL_LIGHT0, GL2.GL_POSITION, lightPosition, 0);
	}

	// -------------------------------- Creating the JPanel properties
	// -----------------------------------------------------

	private void buildJPanel(Container pane) {
		JTabbedPane tabbedPane = new JTabbedPane();
		tabbedPane.add("Toggle panel", getFlowPanel());
		tabbedPane.add("Alpha panel", getColorPanel());

		pane.add(tabbedPane, BorderLayout.CENTER);

		cp.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		cp.setLocation(900, 600);
		cp.setSize(600, 600);
		cp.setVisible(true);

	}

	private JPanel getFlowPanel() {

		JPanel panel1 = new JPanel();
		
//		public static int sx = 250;
//		public static int sy = 80;
//		public static int sz = 350;

		sliceX = new JSlider(JSlider.HORIZONTAL, 0, 500, 250);
		addLabels(sliceX, 100);
		sliceX.addChangeListener(new SliderListener(sliceX, "sx"));
		sliceX.setBorder(new LineBorder(Color.BLACK, 2));
		sliceX.setBorder(BorderFactory.createTitledBorder("XSlice variation"));
		sliceX.setSize(1, 1);
		panel1.add(sliceX);

		sliceY = new JSlider(JSlider.HORIZONTAL, 0, 500, 80);
		addLabels(sliceY, 100);
		sliceY.addChangeListener(new SliderListener(sliceY, "sy"));
		sliceY.setBorder(new LineBorder(Color.BLACK, 2));
		sliceY.setBorder(BorderFactory.createTitledBorder("YSlice variation"));
		sliceY.setSize(1, 1);
		panel1.add(sliceY);

		sliceZ = new JSlider(JSlider.HORIZONTAL, 0, 500, 350);
		addLabels(sliceZ, 100);
		sliceZ.addChangeListener(new SliderListener(sliceZ, "sz"));
		sliceZ.setBorder(new LineBorder(Color.BLACK, 2));
		sliceZ.setBorder(BorderFactory.createTitledBorder("ZSlice variation"));
		sliceZ.setSize(1, 1);
		panel1.add(sliceZ);

		dataSource = new JCheckBox("Displaying data");
		dataSource.setSelected(true);

		panel1.add(dataSource);

		errorSource = new JCheckBox("Displaying error data");
		errorSource.setSelected(false);

		panel1.add(errorSource);

		errorSource1 = new JCheckBox("Displaying error data1");
		errorSource1.setSelected(false);

		panel1.add(errorSource1);

		return panel1;

	}

	private JPanel getColorPanel() {
		JPanel panel3 = new JPanel();

		scale = new JCheckBox("scale");
		scale.setVisible(true);
		panel3.add(scale);

		rotate = new JCheckBox("rotate");
		rotate.setVisible(true);
		panel3.add(rotate);

		angle = new JSlider(JSlider.HORIZONTAL, 0, 360, 0);
		addLabels(angle, 100);
		angle.addChangeListener(new RotSliderListener(angle, "angRot"));
		angle.setBorder(new LineBorder(Color.BLACK, 2));
		angle.setBorder(BorderFactory.createTitledBorder("Rotation slider"));
		angle.setSize(1, 1);
		panel3.add(angle);

		scaleX = new JSlider(JSlider.HORIZONTAL, 0, 2, 0);
		addLabels(scaleX, 3);
		scaleX.addChangeListener(new LightSliderListener(scaleX, "zx"));
		scaleX.setBorder(new LineBorder(Color.BLACK, 2));
		scaleX.setBorder(BorderFactory.createTitledBorder("ScaleX-slider"));
		scaleX.setSize(1, 1);
		panel3.add(scaleX);

		scaleY = new JSlider(JSlider.HORIZONTAL, 0, 2, 0);
		addLabels(scaleY, 3);
		scaleY.addChangeListener(new LightSliderListener(scaleY, "zy"));
		scaleY.setBorder(new LineBorder(Color.BLACK, 2));
		scaleY.setBorder(BorderFactory.createTitledBorder("ScaleY-slider"));
		scaleY.setSize(1, 1);
		//panel3.add(scaleY);

		scaleZ = new JSlider(JSlider.HORIZONTAL, 0, 2, 0);
		addLabels(scaleZ, 3);
		scaleZ.addChangeListener(new LightSliderListener(scaleZ, "zz"));
		scaleZ.setBorder(new LineBorder(Color.BLACK, 2));
		scaleZ.setBorder(BorderFactory.createTitledBorder("ScaleZ-slider"));
		scaleZ.setSize(1, 1);
		//panel3.add(scaleZ);

		return panel3;

	}

	// ---------------- addLabels( JSlider, int ) -----------------------
	/**
	 * a utility method to add tick marks. First argument is the slider, the
	 * second represents the major tick mark interval minor tick mark interval
	 * will be 1/10 of that.
	 */
	private static void addLabels(JSlider slider, int majorTicks) {
		slider.setPaintTicks(true);
		slider.setPaintLabels(true);
		slider.setMajorTickSpacing(majorTicks);
		slider.setMinorTickSpacing(majorTicks / 10);
	}

	// ++++++++++++++++++++++++ SliderListener inner class
	// ++++++++++++++++++++++
	/**
	 * The SliderListener needs access to -- the slider it is associated with
	 * (to get that slider's value) -- the JShape that is being controlled. -- a
	 * string that serves as an identifier for the slider These are passed to
	 * the constructor.
	 */
	public class LightSliderListener implements ChangeListener {
		private JSlider _slider;
		private String _id;

		public LightSliderListener(JSlider slider, String id) {
			_slider = slider;
			_id = id;
		}

		// ------------------- stateChanged -----------------------------
		/**
		 * Invoked whenever user changes the state of a slider
		 */
		public void stateChanged(ChangeEvent ev) {
			// ////////////////////////////////////////////////////////////
			// a. add code to respond to the y-slider. it needs to
			// change the y-position of the target rectangle
			// b. After adding the x-slider, need to test here which slider
			// generated the event; can do that by testing the
			// _id field that was set in the constructor.
			// Compare it (using the String equals method) to the
			// String used to create this instance of the SliderListener.
			// c. After adding the size slider, need to augment this code
			// to identify and handle events from that slider.
			// ///////////////////////////////////////////////////////////

			if (_id.equals("zx"))
				zx = _slider.getValue();
			else if (_id.equals("zy"))
				zy = _slider.getValue();
			else if (_id.equals("zz"))
				zz = _slider.getValue();
			else if (_id.equals("rotateX"))
				rx = _slider.getValue();
			else if (_id.equals("rotateY"))
				ry = _slider.getValue();
			else if (_id.equals("rotateZ"))
				rz = _slider.getValue();
			System.out.println("stateChanged error: ");

			ThreeD.glCanvas.repaint();
			changeTransformation = true;

		}
	}

	// ++++++++++++++++++++++++ SliderListener inner class
	// ++++++++++++++++++++++
	/**
	 * The SliderListener needs access to -- the slider it is associated with
	 * (to get that slider's value) -- the JShape that is being controlled. -- a
	 * string that serves as an identifier for the slider These are passed to
	 * the constructor.
	 */
	public class SliderListener implements ChangeListener {
		private JSlider _slider;
		private String _id;

		public SliderListener(JSlider slider, String id) {
			_slider = slider;
			_id = id;
		}

		// ------------------- stateChanged -----------------------------
		/**
		 * Invoked whenever user changes the state of a slider
		 */
		public void stateChanged(ChangeEvent ev) {
			// ////////////////////////////////////////////////////////////
			// a. add code to respond to the y-slider. it needs to
			// change the y-position of the target rectangle
			// b. After adding the x-slider, need to test here which slider
			// generated the event; can do that by testing the
			// _id field that was set in the constructor.
			// Compare it (using the String equals method) to the
			// String used to create this instance of the SliderListener.
			// c. After adding the size slider, need to augment this code
			// to identify and handle events from that slider.
			// ///////////////////////////////////////////////////////////

			if (_id.equals("sx"))
				sx = _slider.getValue();
			else if (_id.equals("sy"))
				sy = _slider.getValue();
			else if (_id.equals("sz"))
				sz = _slider.getValue();

			else
				System.out.println("stateChanged error: ");

			ThreeD.glCanvas.repaint();
			changeTransformation = true;

		}
	}

	// ++++++++++++++++++++++++ SliderListener inner class
	// ++++++++++++++++++++++
	/**
	 * The SliderListener needs access to -- the slider it is associated with
	 * (to get that slider's value) -- the JShape that is being controlled. -- a
	 * string that serves as an identifier for the slider These are passed to
	 * the constructor.
	 */
	public class RotSliderListener implements ChangeListener {
		private JSlider _slider;
		private String _id;

		public RotSliderListener(JSlider slider, String id) {
			_slider = slider;
			_id = id;
		}

		// ------------------- stateChanged -----------------------------
		/**
		 * Invoked whenever user changes the state of a slider
		 */
		public void stateChanged(ChangeEvent ev) {
			// ////////////////////////////////////////////////////////////
			// a. add code to respond to the y-slider. it needs to
			// change the y-position of the target rectangle
			// b. After adding the x-slider, need to test here which slider
			// generated the event; can do that by testing the
			// _id field that was set in the constructor.
			// Compare it (using the String equals method) to the
			// String used to create this instance of the SliderListener.
			// c. After adding the size slider, need to augment this code
			// to identify and handle events from that slider.
			// ///////////////////////////////////////////////////////////

			if (_id.equals("angRot"))
				angRot = _slider.getValue();

			else
				System.out.println("stateChanged error: ");

			ThreeD.glCanvas.repaint();
			changeTransformation = true;

		}
	}

	// --------------------- buildRadio ------------------------------------
	/**
	 * build a radio button panel with exclusive behavior (1 button pressed at a
	 * time.
	 */
	private void buildRadio() {
		// The ButtonGroup defines a set of RadioButtons that must be
		// "exclusive"
		// -- only 1 can be "active" at a time.

		ButtonGroup bGroup = new ButtonGroup();
		JPanel bPanel = new JPanel(); // defaults to FlowLayout

		bPanel.setBorder(new LineBorder(Color.BLACK, 2));

		String[] labels = { "Blue", "Red", "Green", "Cyan", "Magenta", "Black",
				"Orange" };
		Color[] colors = { Color.BLUE, Color.RED, Color.GREEN, Color.CYAN,
				Color.MAGENTA, Color.BLACK, Color.ORANGE };

		// for each entry in the labels array, create a JRadioButton
		JRadioButton button = null;
		for (int i = 0; i < labels.length; i++) {
			button = new JRadioButton(labels[i]);
			ButtonListener bListen = new ButtonListener(colors[i]);
			button.addActionListener(bListen);
			bGroup.add(button);
			bPanel.add(button);
		}

		button.setSelected(true);

		this.add(bPanel, BorderLayout.NORTH);
	}

	// ++++++++++++++++++++++++ ButtonListener inner class
	// ++++++++++++++++++++++
	/**
	 * This version of the inner ButtonListener class constructor has 2 args:
	 * the JShape being colored the color to be assigned
	 */
	public class ButtonListener implements ActionListener {
		// ------ instance variables ---------------
		Color _color;

		public ButtonListener(Color color) {
			// save the parameter as instance variable of the inner class
			_color = color;
		}

		public void actionPerformed(ActionEvent ev) {
			// get a reference to the radio button that just got pressed.
			JRadioButton button = (JRadioButton) ev.getSource();

			String buttonLabel = button.getText(); // get its text field.
			System.out.println(buttonLabel + ": Action event.  ");
		}
	}

}
