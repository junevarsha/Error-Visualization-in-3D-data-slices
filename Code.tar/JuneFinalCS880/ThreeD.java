/**CS880 Scientific data visualization
 * Project final submission
 * Submitted by 
 * Varsha Thirumakil
 */

/**
 * ThreeD.java - basic 3D JOGL demo
 * 
 * Derived from ThreeD.java, which was derived from Can Xiong code from Fall '12
 *          and threeD.cpp demo
 * 
 * @author rdb
 * @date   October 17, 2013
 *-------------------------------------------

 */

import java.awt.*;

import javax.swing.*;
import javax.media.opengl.*;
import javax.media.opengl.awt.GLCanvas;

import com.jogamp.opengl.util.gl2.GLUT;

//----------------- class variables -------------------------------
public class ThreeD extends JFrame {
	// -------------------- class variables ----------------------------
	private static int windowWidth = 1000; // default size
	private static int windowHeight = 1200;

	// ----------------- instance variables -------------------------------
	private int width, height; // current window size
	private SliceQuad sceneManager = null;
	public static GLCanvas glCanvas = null;
	static ControlPanel controlPanel = ControlPanel.getInstance();

	ControlPanel cp = ControlPanel.getInstance();

	// ------------------ constructors ----------------------------------
	public ThreeD(int w, int h) {
		super("ThreeD demo");
		width = w;
		height = h;

		this.setSize(width, height);

		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		sceneManager = SliceQuad.getInstance();

		setupOpenGL();

		ControlPanel controlPanel = ControlPanel.getInstance();
		controlPanel.addDrawPanel(glCanvas);
		this.add(controlPanel);

		this.setVisible(true);
	}

	// --------------------- setupOpenGL( int win ) -------------------------
	/**
	 * Set up the open GL drawing window
	 */
	void setupOpenGL() {
		GLProfile glp = GLProfile.getDefault();
		GLCapabilities caps = new GLCapabilities(glp);
		glCanvas = new GLCanvas(caps);

		// When a GL event occurs, need to tell the canvas to send the event
		// to the ThreeD object, which knows how to draw the scene.
		glCanvas.addGLEventListener(sceneManager);
		sceneManager.setCanvas(glCanvas);

		// This program doesn't need an animator since all image changes
		// occur because of interactions with the user and should
		// get triggered as long as the GLCanvas.repaint method is called.
	}

	// ++++++++++++++++++++++++++++ main ++++++++++++++++++++++++++++++++++++++
	public static void main(String[] args) {
		ThreeD scene = new ThreeD(windowWidth, windowHeight);
	}

}
