import javax.media.opengl.GL2;
import javax.swing.JSlider;

public class Model extends Object3D {

	Quad obj1;
	Quad obj2;
	Quad obj3;
	
	private boolean rotateModel ; 
	private float modelRotateAngle ; 

	public Model(Quad box1, Quad box2, Quad box3) {
		obj1 = box1;
		obj2 = box2;
		obj3 = box3;
		rotateModel = false ; 
	}
	

	public Quad getObj1() {
		return obj1;
	}

	public void setObj1(Quad obj1) {
		this.obj1 = obj1;
	}

	public Quad getObj2() {
		return obj2;
	}

	public void setObj2(Quad obj2) {
		this.obj2 = obj2;
	}

	public Quad getObj3() {
		return obj3;
	}

	public void setObj3(Quad obj3) {
		this.obj3 = obj3;
	}	
	

	public boolean isRotateModel() {
		return rotateModel;
	}


	public void setRotateModel(boolean rotateModel) {
		this.rotateModel = rotateModel;
	}

	public float getModelRotateAngle() {
		return modelRotateAngle;
	}


	public void setModelRotateAngle(float modelRotateAngle) {
		this.modelRotateAngle = modelRotateAngle;
	}


	@Override
	protected void drawPrimitives() {
		// TODO Auto-generated method stub
		//JOGL.gl.glBegin(GL2.GL_POLYGON);
		
		//JOGL.gl.glPushMatrix();


		// rot

//		if(isRotateModel()){ 
//			JOGL.gl.glRotatef(getModelRotateAngle(), 0.0f, 1.0f, 0.0f);
//		}
		
		if(ControlPanel.rotate.isSelected()){ 
			JOGL.gl.glRotatef(ControlPanel.angRot, 0.0f, 1.0f, 0.0f);
		}
		
		obj1.redraw();
		obj2.redraw();
		obj3.redraw();
		
	



	}

}
