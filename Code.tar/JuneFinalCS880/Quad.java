/**CS880 Scientific data visualization
 * Project final submission
 * Submitted by 
 * Varsha Thirumakil
 */

import java.io.IOException;
import java.io.InputStream;

import javax.media.opengl.GL;
import javax.media.opengl.GL2;
import javax.media.opengl.glu.GLUquadric;

import com.jogamp.opengl.util.texture.Texture;
import com.jogamp.opengl.util.texture.TextureIO;

/**
 * Box.java - a class implementation representing a Box object in OpenGL Oct 16,
 * 2013 rdb - derived from Box.cpp
 */

public class Quad extends Object3D {
	// --------- instance variables -----------------
	float length;

	float r1 = 0.0f; // for the spinning panel
	float replication = 1.0f; // # copies of texture on quad in each direction
	float offset = 0.0f; // offset of map origin as % of quad in x and y
	int deltaRep = 1;
	int revolution = 0; // how many complete revolutions have been made.

	int sliceAxis;

	// ------------- constructor -----------------------
	public Quad() {
		length = 1;
	}

	// ------------- drawPrimitives ---------------------------
	public void drawPrimitives() {

		Texture tex = dataTex;

		if (ControlPanel.dataSource.isSelected()) {
			ControlPanel.errorSource.setSelected(false);
			tex = dataTex;
		} else if (ControlPanel.errorSource.isSelected()) {
			ControlPanel.errorSource1.setSelected(false);
			ControlPanel.dataSource.setSelected(false);
			tex = errorTex;
		} else if (ControlPanel.errorSource1.isSelected()) {
			ControlPanel.dataSource.setSelected(false);
			ControlPanel.errorSource.setSelected(false);
			tex = errorTex1;
		}
		// JOGL.gl.glPushMatrix();
		if (tex != null && JOGL.gl != null) {
			tex.enable(JOGL.gl);
			tex.bind(JOGL.gl);
		}

		/*
		 * ---------- Quad ------
		 */

		// JOGL.gl.glTranslatef(controlPanel.tx + 0.0f, controlPanel.ty + 0.0f,
		// controlPanel.tz - 2.);

		if (ControlPanel.scale.isSelected()) {
			float s1 = controlPanel.zx;
			float s2 = controlPanel.zy;
			float s3 = controlPanel.zz;
			JOGL.gl.glScalef(s1 + 1.0f, s2 + 1.0f, s3 + 2.0f);
		}
		// else if (ControlPanel.rotate.isSelected())
		//
		// {
		// JOGL.gl.glRotatef(controlPanel.angRot, 0.0f, 1.0f, 0.0f);
		// }

		JOGL.gl.glBegin(GL2.GL_POLYGON);
		// gl.glBegin( GL2.GL_QUADS );
		// Lower left quad corner
		JOGL.gl.glTexCoord2f(offset, offset);
		JOGL.gl.glVertex3f(-1.0f, -1.0f, 0.0f);

		// Lower right quad corner
		JOGL.gl.glTexCoord2f(replication + offset, offset);
		JOGL.gl.glVertex3f(1.0f, -1.0f, 0.0f);

		// Upper right quad corner
		JOGL.gl.glTexCoord2f(replication + offset, replication + offset);
		JOGL.gl.glVertex3f(1.0f, 1.0f, 0.0f);

		// Upper left quad corner
		JOGL.gl.glTexCoord2f(offset, replication + offset);
		JOGL.gl.glVertex3f(-1.0f, 1.0f, 0.0f);

		JOGL.gl.glEnd();

		//JOGL.gl.glPopMatrix();
		
		if (tex != null && JOGL.gl != null)
		{
		tex.disable(JOGL.gl);
		}

	}
}
