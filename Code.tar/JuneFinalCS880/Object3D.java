/**CS880 Scientific data visualization
 * Project final submission
 * Submitted by 
 * Varsha Thirumakil
 */
/**
 * Object3D.java - an abstract class representing an OpenGL graphical object
 *
 * 10/16/13 rdb derived from Object3D.cpp
 */
import java.io.*;
import java.util.*;
import java.awt.Color;
import java.awt.image.BufferedImage;

import javax.media.opengl.GLProfile;
import javax.media.opengl.awt.GLCanvas;
import javax.swing.JFrame;

import com.jogamp.opengl.util.FPSAnimator;
import com.jogamp.opengl.util.texture.Texture;
import com.jogamp.opengl.util.texture.TextureIO;
import com.jogamp.opengl.util.texture.awt.AWTTextureIO;

abstract public class Object3D extends AWTTextureIO {
	// ------------------ class variables ------------------------------
	static final int MAX_COLORS = 20; // arbitrary number to keep an parameter

	private static final BufferedImage BufferedImage = null;

	// ------------------ instance variables ------------------------------
	protected float xLoc, yLoc, zLoc; // location (origin) of the object
	protected float xSize, ySize, zSize; // size of the object
	protected float angle, dxRot, dyRot, dzRot; // rotation angle and axis

	protected float tx, ty, tz; // translate axis

	protected float init_x, init_y, init_z;
	protected float init_angle, init_xr, init_yr, init_zr;

	protected ArrayList<Color> colors;
	protected Texture dataTex;
	protected Texture errorTex;
	protected Texture errorTex1;

	protected abstract void drawPrimitives();

	public static ControlPanel controlPanel = ControlPanel.getInstance();

	// ------------------ Constructors ------------------------------------
	/**
	 * Create a new object3D at position 0,0,0 of size 1,1,1
	 */
	Object3D() {
		colors = new ArrayList<Color>();
		Color color = new Color(1.0f, 0.0f, 0.0f); // red is default
		colors.add(color);
		// string arry obj arr[0] =

		ThreeD.glCanvas.repaint();
		setLocation(0, 0, 0);
		setSize(0.2f, 0.3f, 0.4f);
		setRotate(0, 0, 0, 0);

	}

	public Texture getDataTex() {
		return dataTex;
	}

	public void setDataTex(Texture dataTex) {
		this.dataTex = dataTex;
	}

	public Texture getErrorTex() {
		return errorTex;
	}

	public void setErrorTex(Texture errorTex) {
		this.errorTex = errorTex;
	}

	public Texture getErrorTex1() {
		return errorTex1;
	}

	public void setErrorTex1(Texture errorTex1) {
		this.errorTex1 = errorTex1;
	}

	// ------------------ public methods -------------------------------
	// ------------- redraw ---------------------------
	void redraw() {
		// std::cout <<"++++++++++++++++ cube redraw+++++++++++++" << std::endl;
		JOGL.gl.glPushMatrix();
		float[] rgb = colors.get(0).getComponents(null);
		JOGL.gl.glColor3f(rgb[0], rgb[1], rgb[2]);

		JOGL.gl.glTranslatef(xLoc, yLoc, zLoc);
		JOGL.gl.glRotatef(angle, dxRot, dyRot, dzRot);
		//float r1 = controlPanel.angRot;

		//JOGL.gl.glRotatef(r1, 0.0f, 1.0f, 0.0f);

		JOGL.gl.glScalef(xSize, ySize, zSize);

		drawPrimitives();

		JOGL.gl.glPopMatrix();
	}

	/**
	 * set the location of the object to the x,y,z position defined by the args
	 */
	void setLocation(float x, float y, float z) {
		xLoc = x;
		yLoc = y;
		zLoc = z;
	}

	/**
	 * return the value of the x origin of the shape
	 */
	float getX() {
		return xLoc;
	}

	/**
	 * return the value of the y origin of the shape
	 */
	float getY() {
		return yLoc;
	}

	/**
	 * return the value of the z origin of the shape
	 */
	float getZ() {
		return zLoc;
	}

	/**
	 * return the location as a Point3 object
	 */
	Point3 getLocation() // return location as a Point
	{
		return new Point3(xLoc, yLoc, zLoc);
	}

	// ----------------------- setColor methods ---------------------------
	/**
	 * set the "nominal" color of the object to the specified color; this does
	 * not require that ALL components of the object must be the same color.
	 * Typically, the largest component will take on this color, but the
	 * decision is made by the child class.
	 */
	void setColor(Color c) {
		setColor(0, c);
	}

	/**
	 * set the nominal color (index 0) to the specified color with floats
	 */
	void setColor(float r, float g, float b) {
		setColor(0, new Color(r, g, b));
	}

	/**
	 * set the index color entry to the specified color with floats
	 */
	void setColor(int i, float r, float g, float b) {
		setColor(i, new Color(r, g, b));
	}

	/**
	 * set the i-th color entry to the specified color with Color
	 */
	void setColor(int i, Color c) {
		if (i < 0 || i > MAX_COLORS) // should throw an exception!
		{
			System.err.println("*** ERROR *** Object3D.setColor: bad index: "
					+ i + "\n");
			return;
		}
		float[] rgb = c.getComponents(null);
		Color newColor = new Color(rgb[0], rgb[1], rgb[2]);
		if (i >= colors.size()) // need to add entries to vector
		{
			for (int n = colors.size(); n < i; n++)
				// fill w/ black if needed
				colors.add(Color.BLACK);
			colors.add(newColor); // put desired color at desired index
		} else {
			// now replace old entry
			colors.set(i, newColor);
		}
	}

	// ------------------ setSize ----------------------------------------
	/**
	 * set the size of the shape to be scaled by xs, ys, zs That is, the shape
	 * has an internal fixed size, the shape parameters scale that internal
	 * size.
	 */
	void setSize(float xs, float ys, float zs) {
		xSize = xs;
		ySize = ys;
		zSize = zs;
	}

	// ------------------ setLocation ----------------------------------------
	/**
	 * set the size of the shape to be scaled by xs, ys, zs That is, the shape
	 * has an internal fixed size, the shape parameters scale that internal
	 * size.
	 */

	/**
	 * set the rotation parameters: angle, and axis specification
	 */
	void setRotate(float a, float dx, float dy, float dz) {
		angle = a;
		dxRot = dx;
		dyRot = dy;
		dzRot = dz;
	}
}