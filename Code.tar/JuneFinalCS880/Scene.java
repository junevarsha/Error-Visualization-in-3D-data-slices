/**CS880 Scientific data visualization
 * Project final submission
 * Submitted by 
 * Varsha Thirumakil
 */
/**
 * Scene.java - a class to represent a scene: its objects and its view
 * 
 * 10/16/13 rdb derived from Scene.cpp
 */

import java.util.*;
import java.io.*;

import javax.media.opengl.*;
import javax.media.opengl.awt.GLCanvas;
import javax.media.opengl.glu.*;
import javax.media.opengl.fixedfunc.*;
import javax.swing.text.html.ObjectView;

import com.jogamp.opengl.util.*;
import com.jogamp.opengl.util.gl2.GLUT;

public class Scene {
	// ------------------ class variables ------------------------------
	// ---- draw Axes flag ------------------------
	static boolean drawAxes;
	// package access
	static boolean lighting;

	// ------------------ instance variables ------------------------------
	// ---- objects collection -------
	ArrayList<Object3D> objects;

	// ----gluLookat parameters -------
	float eyeX, eyeY, eyeZ; // gluLookat eye position
	float lookX, lookY, lookZ; // gluLookat look position
	float upX, upY, upZ; // up vector

	// ----gluPerspective parameters ----
	float viewAngle, aspectRatio, near, far;
	// ----glOrtho parameters -------
	float left, right, bottom, top, nearVal, farVal;
	public static ControlPanel controlPanel = ControlPanel.getInstance();

	// ------------------ Constructors ------------------------------------
	/**
	 * Initialize any values, register callbacks
	 */
	public Scene() {
		objects = new ArrayList<Object3D>();
		resetView();
		drawAxes = true;
	}

	// ----------- changeEvent -------------------------------------------
	static float delta = 0.1f;

	public void changeEvent(String id, int value) {
		if (objects.size() > 0) {
			Object3D obj = objects.get(0);
			float x = obj.getX();
			float y = obj.getY();
			float z = obj.getZ();
			if (delta < 0 && x < 0)
				delta = -delta;
			else if (delta > 0 && x > 2)
				delta = -delta;
			obj.setLocation(x + delta, y, z);
		}
	}

	// -------------- resetView -----------------------------------------
	/**
	 * restore the view to default settings
	 */
	public void resetView() {
		setLookat(10, 3, 10, // eye
				0, 0, 0, // at
				0, 1, 0); // up

		setPerspective(10, 1.33f, 0.1f, 100.0f); // should calc windowWid /

		// setOrtho(0.0f, 50.0f, 0.0f, 50.0f, -50.0f, 50.0f );
		// windowHt
	}

	// --------------------------------------------------------------------
	public void addObject(Object3D newObject) {
		objects.add(newObject);
	}

	// --------------------------------------------------------------------
	public void clear() {
		objects.clear();
		redraw();
	}

	// ---------------------------------------------------------------------
	/**
	 * set lookat parameters
	 */
	public void setLookat(float eyeX, float eyeY, float eyeZ, float lookX,
			float lookY, float lookZ, float upX, float upY, float upZ) {
		this.eyeX = eyeX;
		this.eyeY = eyeY;
		this.eyeZ = eyeZ;
		this.lookX = lookX;
		this.lookY = lookY;
		this.lookZ = lookZ;
		this.upX = upX;
		this.upY = upY;
		this.upZ = upZ;
	}

	// ---------------------------------------------------------------------
	/**
	 * set perspective parameters
	 */
	void setPerspective(float angle, float ratio, float near, float far) {
		this.viewAngle = angle;
		this.aspectRatio = ratio;
		this.near = near;
		this.far = far;
	}

	// ---------------------------------------------------------------------
	/**
	 * set perspective parameters
	 */
	void setOrtho(float left, float right, float bottom, float top,
			float nearVal, float farVal) {
		this.left = left;
		this.right = right;
		this.bottom = bottom;
		this.top = top;
		this.nearVal = nearVal;
		this.farVal = farVal;
	}

	// ---------------- drawing coordinate axes -----------------------
	/**
	 * Draw the world coord axes to help orient viewer.
	 */
	void drawCoordinateAxes() {

		float scale = 0.8f; // convenient scale factor for experimenting with
							// size
		float scale1 = 0.7f;
		float scale2 = 0.6f;
		JOGL.gl.glPushMatrix();

		JOGL.gl.glDisable(GLLightingFunc.GL_LIGHTING);
		JOGL.gl.glScalef(scale, scale1, scale2);
		JOGL.gl.glLineWidth(3);

		JOGL.gl.glBegin(GL2.GL_LINE_LOOP);
		// Front Face
		// JOGL.gl.glNormal3f(0.0f, 0.0f, 1.0f);
		// JOGL.gl.glColor3f(1, 0, 0); // X axis is red.

//		JOGL.gl.glVertex3f(-1.0f, -1.0f, 1.0f);
//
//		JOGL.gl.glVertex3f(1.0f, -1.0f, 1.0f);
//
//		JOGL.gl.glVertex3f(1.0f, 1.0f, 1.0f);
//
//		JOGL.gl.glVertex3f(-1.0f, 1.0f, 1.0f);
//		JOGL.gl.glEnd();
		
		/*
		 * --->
		 */
		
//		JOGL.gl.glVertex3f(-0.7f, -0.9f, 0.7f);
//
//		JOGL.gl.glVertex3f(0.7f, -0.9f, 0.7f);
//
//		JOGL.gl.glVertex3f(0.7f, 0.9f, 0.7f);
//
//		JOGL.gl.glVertex3f(-0.7f, 0.9f, 0.7f);
//		JOGL.gl.glEnd();


		// Back Face
		// JOGL.gl.glColor3f(0, 1, 0); // X axis is red.
		// JOGL.gl.glNormal3f(0.0f, 0.0f, -1.0f);

		JOGL.gl.glBegin(GL2.GL_LINE_LOOP);

		JOGL.gl.glVertex3f(-1.0f, -1.0f, -1.0f);

		JOGL.gl.glVertex3f(-1.0f, 1.0f, -1.0f);

		JOGL.gl.glVertex3f(1.0f, 1.0f, -1.0f);

		JOGL.gl.glVertex3f(1.0f, -1.0f, -1.0f);
		JOGL.gl.glEnd();
		
		//************--
		
//		JOGL.gl.glBegin(GL2.GL_LINE_LOOP);
//
//		JOGL.gl.glVertex3f(-0.7f, -0.7f, -0.7f);
//
//		JOGL.gl.glVertex3f(-0.7f, 0.7f, -0.7f);
//
//		JOGL.gl.glVertex3f(0.7f, 0.7f, -0.7f);
//
//		JOGL.gl.glVertex3f(0.7f, -0.7f, -0.7f);
//		JOGL.gl.glEnd();
		
		//*************
		
		
		// Top Face

		// JOGL.gl.glColor3f(0, 1, 1); // X axis is red.
		// JOGL.gl.glNormal3f(0.0f, 1.0f, 0.0f);
		JOGL.gl.glBegin(GL2.GL_LINE_LOOP);
		JOGL.gl.glVertex3f(-1.0f, 1.0f, -1.0f);

		JOGL.gl.glVertex3f(-1.0f, 1.0f, 1.0f);

		JOGL.gl.glVertex3f(1.0f, 1.0f, 1.0f);

		JOGL.gl.glVertex3f(1.0f, 1.0f, -1.0f);
		JOGL.gl.glEnd();

		//*************
//		JOGL.gl.glBegin(GL2.GL_LINE_LOOP);
//		JOGL.gl.glVertex3f(-0.7f, 0.7f, -0.7f);
//
//		JOGL.gl.glVertex3f(-0.7f, 0.7f, 0.7f);
//
//		JOGL.gl.glVertex3f(0.7f, 0.7f, 0.7f);
//
//		JOGL.gl.glVertex3f(0.7f, 0.7f, -0.7f);
//		JOGL.gl.glEnd();
		
		//*************

		
		
		// Bottom Face
		// JOGL.gl.glColor3f(1, 1, 0); // X axis is red.
		// JOGL.gl.glNormal3f(0.0f, -1.0f, 0.0f);
		JOGL.gl.glBegin(GL2.GL_LINE_LOOP);
		JOGL.gl.glVertex3f(-1.0f, -1.0f, -1.0f);

		JOGL.gl.glVertex3f(1.0f, -1.0f, -1.0f);

		JOGL.gl.glVertex3f(1.0f, -1.0f, 1.0f);

		JOGL.gl.glVertex3f(-1.0f, -1.0f, 1.0f);
		
		//**********
		
//		JOGL.gl.glBegin(GL2.GL_LINE_LOOP);
//		JOGL.gl.glVertex3f(-0.7f, -0.7f, -0.7f);
//
//		JOGL.gl.glVertex3f(0.7f, -0.7f, -0.7f);
//
//		JOGL.gl.glVertex3f(0.7f, -0.7f, 0.7f);
//
//		JOGL.gl.glVertex3f(-0.7f, -0.7f, 0.7f);
//		
		JOGL.gl.glEnd();
		//**********
		
		
		// Right face
		// JOGL.gl.glColor3f(1, 0.3f, 0); // X axis is red.
		// JOGL.gl.glNormal3f(1.0f, 0.0f, 0.0f);
		JOGL.gl.glBegin(GL2.GL_LINE_LOOP);
		JOGL.gl.glVertex3f(1.0f, -1.0f, -1.0f);

		JOGL.gl.glVertex3f(1.0f, 1.0f, -1.0f);

		JOGL.gl.glVertex3f(1.0f, 1.0f, 1.0f);

		JOGL.gl.glVertex3f(1.0f, -1.0f, 1.0f);
		JOGL.gl.glEnd();
		// Left Face
		
		//****************
//		JOGL.gl.glBegin(GL2.GL_LINE_LOOP);
//		JOGL.gl.glVertex3f(0.7f, -0.7f, -0.7f);
//
//		JOGL.gl.glVertex3f(0.7f, 0.7f, -0.7f);
//
//		JOGL.gl.glVertex3f(0.7f, 0.7f, 0.7f);
//
//		JOGL.gl.glVertex3f(0.7f, -0.7f, 0.7f);
//		JOGL.gl.glEnd();
		//*****************

		// JOGL.gl.glColor3f(0.3f, 1, 0.2f); // X axis is red.
		// JOGL.gl.glNormal3f(-1.0f, 0.0f, 0.0f);
		JOGL.gl.glBegin(GL2.GL_LINE_LOOP);
		JOGL.gl.glVertex3f(-1.0f, -1.0f, -1.0f);

		JOGL.gl.glVertex3f(-1.0f, -1.0f, 1.0f);

		JOGL.gl.glVertex3f(-1.0f, 1.0f, 1.0f);

		JOGL.gl.glVertex3f(-1.0f, 1.0f, -1.0f);

		JOGL.gl.glEnd();
		
//		JOGL.gl.glBegin(GL2.GL_LINE_LOOP);
//		JOGL.gl.glVertex3f(-0.7f, -0.7f, -0.7f);
//
//		JOGL.gl.glVertex3f(-0.7f, -0.7f, 0.7f);
//
//		JOGL.gl.glVertex3f(-0.7f, 0.7f, 0.7f);
//
//		JOGL.gl.glVertex3f(-0.7f, 0.7f, -0.7f);
//
//		JOGL.gl.glEnd();
		
		JOGL.gl.glPopMatrix();
		JOGL.gl.glEnable(GLLightingFunc.GL_LIGHTING);

	}

	void lighting() {
		if (ControlPanel.light.isSelected()) {
			ControlPanel.light_on = ControlPanel.light.isSelected();
			ControlPanel.light_on = true;
		}
		if (ControlPanel.light_on) {
			// Light is set ON
			JOGL.gl.glEnable(JOGL.gl.GL_LIGHTING);
			JOGL.gl.glEnable(JOGL.gl.GL_LIGHT0);

			ControlPanel.light_on = false;
		} else {
			// Light is set OFF
			JOGL.gl.glDisable(JOGL.gl.GL_LIGHTING);
			JOGL.gl.glDisable(JOGL.gl.GL_LIGHT0);
			// TextureDemo.glCanvas.repaint();
		}

	}

	// ---------------------------------------------------------------------
	public void display(GLAutoDrawable drawable) {
		// redraw( drawable );
		redraw();

	}

	public void redraw() {
		// SceneManager.me.sceneInit();
		// Should I use the passed drawable or JOGL.gl???
		JOGL.gl.glMatrixMode(GL2.GL_PROJECTION);
		JOGL.gl.glLoadIdentity(); // Reset The Projection Matrix

		// Only do perspective for now
		JOGL.glu.gluPerspective(viewAngle, aspectRatio, near, far);
		// JOGL.gl.glOrtho(0, 50, 0, 50 , -50, 50);
		JOGL.gl.glMatrixMode(GL2.GL_MODELVIEW);
		JOGL.gl.glLoadIdentity(); // Reset The Projection Matrix

		JOGL.glu.gluLookAt(eyeX, eyeY, eyeZ, lookX, lookY, lookZ, upX, upY, upZ);

		JOGL.gl.glClear(GL2.GL_DEPTH_BUFFER_BIT | GL2.GL_COLOR_BUFFER_BIT);

		if (SliceQuad.drawAxes())
			drawCoordinateAxes();

		if (SliceQuad.lighting())
			lighting();

		for (Object3D obj : objects)
			obj.redraw();

		JOGL.gl.glFlush(); // send all output to display
	}

	// ---------------- setDrawAxes( int ) -----------------------
	/**
	 * 0 means don't draw the axes non-zero means draw them
	 */
	// -------------------------------------------
	public void setDrawAxes(boolean yesno) {
		drawAxes = yesno;
	}

	public void setLighting(boolean yesno) {
		lighting = yesno;
	}
}